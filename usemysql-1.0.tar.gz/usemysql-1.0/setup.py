# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   Author :       dangliuhui
   date：          2018/3/9
-------------------------------------------------
"""
from distutils.core import setup

setup(name="usemysql", version="1.0", description="use mysql database simple!", author="BaAGee",
      py_modules=['usemysql.Dao', 'usemysql.MySQLDB'])

# python setup.py build

# python setup.py sdist

# 找到模块的压缩包
# 解压 tar zxvf xxx.tar.gz
# 进入文件夹
# 执行命令python setup.py install
